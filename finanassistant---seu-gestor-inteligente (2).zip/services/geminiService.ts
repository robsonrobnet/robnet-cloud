
import { GoogleGenerativeAI } from "@google/generative-ai";
import { Transaction, Language, NfseClient } from "../types";

export interface Attachment {
  mimeType: string;
  data: string; // Base64 for binary, or raw string for text/csv
}

// --- KEYS ---
const getGeminiKey = (): string | undefined => {
  return localStorage.getItem('finanai_gemini_key') || process.env.API_KEY || 'AIzaSyDuAqwcp3_rulydp6OjkPv1uzcFTGgedzQ';
};

const getOpenAIKey = (): string | undefined => {
  return localStorage.getItem('finanai_openai_key') || undefined;
};

// --- SYSTEM PROMPT (SHARED) ---
const SYSTEM_PROMPT = `
    ## 🤖 PERFIL: GERENTE FINANCEIRO & CONTÁBIL
    Atue como um **Gerente Financeiro Sênior**. Seu objetivo é o controle rigoroso de fluxo de caixa, conciliação bancária e gestão de documentos fiscais (NFS-e).
    
    ## 📏 DIRETRIZES DE RESPOSTA
    - **Tom:** Formal, Técnico e Conciso. Evite saudações excessivas.
    - **Formato:** Utilize tópicos, quebras de linha e emojis para hierarquia visual (✅, ⚠️, 📅, 📉).
    - **Conteúdo:** Foque em valores, datas de vencimento e status da conta.

    ## 🛡️ ANÁLISE DE BANCO DE DADOS (Contexto CSV)
    Você recebeu um extrato do banco de dados (CSV). Utilize-o para:
    1. **Reconciliação:** Se o usuário informar um pagamento, busque o ID correspondente pelo Valor e Descrição.
    2. **Status:** 
       - Reconheça 'PAID' como **Liquidado**.
       - Reconheça 'PENDING' como **Pendente**.
       - Se (Data Atual > Data Vencimento) e status 'PENDING', trate como **ATRASADO/INADIMPLENTE**.
    3. **Cartões/Empréstimos:** Identifique parcelamentos ("1/12", "Fatura", "Empréstimo").

    ## 🏦 IMPORTAÇÃO DE ARQUIVOS (OFX / CSV / EXCEL)
    Se o input contiver dados estruturados (XML de OFX ou CSV):
    1. **OFX (Open Financial Exchange):** Procure tags como <TRNAMT> (Valor), <MEMO> (Descrição), <DTPOSTED> (Data).
       - Valores negativos em <TRNAMT> são SAÍDAS (EXPENSE).
       - Valores positivos são ENTRADAS (INCOME).
    2. **Inteligência de Categorização:**
       - Analise a descrição (<MEMO> ou coluna Descrição) para inferir a categoria (ex: "Uber" -> "Logística", "AWS" -> "Infraestrutura Cloud").
       - Se for "Pix", tente inferir o propósito pelo contexto ou marque como "Outros".
    3. **Normalização:** Converta todas as datas para YYYY-MM-DD.

    ## ⚙️ PROTOCOLO DE AÇÃO
    
    ### 1. BAIXA E PAGAMENTOS (Updates)
    Se o comando for "Pagar conta X" ou "Baixar fatura Y":
    - Localize o ID no contexto.
    - Retorne JSON de update com \`status: 'PAID'\`.
    - Resposta Texto: "✅ Pagamento registrado: **[Descrição]** | Valor: **R$ [Valor]**."

    ### 2. NOVOS LANÇAMENTOS (Creation)
    - **RETORNE APENAS UM ÚNICO OBJETO JSON** no array \`extractedTransactions\` representando a 1ª parcela ou o mês atual.
    - Configure \`installment_current: 1\` e \`installment_total: X\` (para parcelados).
    - Ou configure \`is_recurring: true\` (para assinaturas fixas).

    ### 3. CADASTRO DE CLIENTES (NFS-e)
    - Gere um objeto JSON no array \`extractedClients\`.

    ## 📝 FORMATO DE SAÍDA (JSON OBRIGATÓRIO)
    Ao final da resposta textual, inclua estritamente o bloco JSON para execução no app:

    \`\`\`json
    {
      "extractedTransactions": [ ... ],
      "extractedClients": [ ... ],
      "updates": [ { "id": "uuid", "fields": { "status": "PAID" } } ],
      "deletions": [ "uuid" ]
    }
    \`\`\`
`;

// --- TEST FUNCTIONS ---

export const testGeminiConnection = async (apiKey: string): Promise<{ success: boolean; message?: string }> => {
  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-3-flash-preview" });
    await model.generateContent("Hello check");
    return { success: true };
  } catch (error: any) {
    console.error("Gemini Test Failed:", error);
    return { success: false, message: error.message || "Falha na conexão" };
  }
};

export const testOpenAIConnection = async (apiKey: string): Promise<{ success: boolean; message?: string }> => {
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({
            model: "gpt-4o-mini", // Modelo leve para teste
            messages: [{ role: "user", content: "ping" }],
            max_tokens: 5
        })
    });
    
    if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error?.message || response.statusText);
    }
    return { success: true };
  } catch (error: any) {
    console.error("OpenAI Test Failed:", error);
    return { success: false, message: error.message || "Falha na conexão OpenAI" };
  }
};

// --- PROCESSORS ---

const processWithGemini = async (apiKey: string, promptText: string, attachment?: Attachment) => {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ 
      model: "gemini-3-flash-preview",
      systemInstruction: SYSTEM_PROMPT
    });

    const parts: any[] = [];
    if (attachment) {
      // Gemini lida com texto puro para CSV/OFX para melhor análise
      const isTextData = attachment.mimeType === 'text/csv' || attachment.mimeType === 'text/ofx' || attachment.mimeType.startsWith('text/');
      if (isTextData) {
        promptText += `\n\n[CONTEÚDO DO ARQUIVO ANEXADO (${attachment.mimeType})]\n${attachment.data}`;
      } else {
        const base64Data = attachment.data.includes('base64,') ? attachment.data.split(',')[1] : attachment.data;
        parts.push({ inlineData: { mimeType: attachment.mimeType, data: base64Data } });
      }
    }
    parts.push({ text: promptText });

    const result = await model.generateContent(parts);
    const response = await result.response;
    
    if (response.promptFeedback && response.promptFeedback.blockReason) {
       throw new Error(`Gemini Blocked: ${response.promptFeedback.blockReason}`);
    }
    return response.text();
};

const processWithOpenAI = async (apiKey: string, promptText: string, attachment?: Attachment, dbContext?: string) => {
    const messages: any[] = [
        { role: "system", content: SYSTEM_PROMPT + (dbContext ? `\n[CONTEXTO BANCO DE DADOS]\n${dbContext}` : "") }
    ];

    let userContent: any[] = [{ type: "text", text: promptText }];

    if (attachment) {
        if (attachment.mimeType.startsWith('image/')) {
            // OpenAI Vision
            const dataUrl = attachment.data.startsWith('data:') ? attachment.data : `data:${attachment.mimeType};base64,${attachment.data}`;
            userContent.push({
                type: "image_url",
                image_url: { url: dataUrl }
            });
        } else {
            // Text Append
            const content = `\n\n[ARQUIVO ANEXO - ${attachment.mimeType}]\n${attachment.data}`;
            userContent[0].text += content;
        }
    }

    messages.push({ role: "user", content: userContent });

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            model: "gpt-4o", // Melhor para JSON complexo
            messages: messages,
            response_format: { type: "json_object" }, // Força JSON
            temperature: 0.1
        })
    });

    const data = await response.json();
    if (data.error) throw new Error(`OpenAI Error: ${data.error.message}`);
    
    return data.choices[0].message.content;
};

// --- MAIN FUNCTION ---

export const analyzeFinancialInput = async (
  input: string, 
  attachment?: Attachment, 
  lang: Language = 'pt',
  dbContext?: string,
  chatHistory: { role: string; parts: { text: string }[] }[] = []
): Promise<{
  textResponse: string;
  extractedTransactions?: Partial<Transaction & { cnpj?: string }>[];
  extractedClients?: Partial<NfseClient>[];
  updates?: { id: string; fields: Partial<Transaction> }[];
  deletions?: string[];
}> => {
  const geminiKey = getGeminiKey();
  const openAIKey = getOpenAIKey();
  
  let rawText = "";
  let providerUsed = "NONE";

  // 1. TENTA GEMINI
  if (geminiKey) {
      try {
          const finalPrompt = input + (dbContext ? `\n[CONTEXTO FINANCEIRO ATUAL (CSV)]\n${dbContext}` : '');
          rawText = await processWithGemini(geminiKey, finalPrompt, attachment);
          providerUsed = "GEMINI";
      } catch (e: any) {
          console.warn("⚠️ Gemini falhou, tentando fallback...", e.message);
          // Se não tiver chave OpenAI, lança o erro do Gemini mesmo
          if (!openAIKey) {
              return { textResponse: `⚠️ Erro no Gemini e sem fallback configurado: ${e.message}` };
          }
      }
  }

  // 2. TENTA OPENAI (FALLBACK)
  if (!rawText && openAIKey) {
      try {
          rawText = await processWithOpenAI(openAIKey, input, attachment, dbContext);
          providerUsed = "OPENAI";
      } catch (e: any) {
          console.error("OpenAI Fallback Failed:", e);
          return { textResponse: `⚠️ Erro Crítico: Falha em ambos provedores de IA (Gemini e OpenAI). Detalhes: ${e.message}` };
      }
  }

  if (!rawText) {
      return { textResponse: "⚠️ Erro: Chave de API não configurada (Gemini ou OpenAI). Vá em Configurações." };
  }

  // 3. PARSE JSON (SHARED LOGIC)
  let extractedTransactions: any[] = [];
  let extractedClients: any[] = [];
  let updates: any[] = [];
  let deletions: string[] = [];
  let cleanTextResponse = rawText;

  try {
      const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      let parsed = null;

      if (jsonMatch && jsonMatch[1]) {
          parsed = JSON.parse(jsonMatch[1]);
          cleanTextResponse = rawText.replace(/```(?:json)?\s*[\s\S]*?\s*```/, "").trim();
      } else {
          // Tentativa de achar JSON puro se não tiver markdown
          const firstBrace = rawText.indexOf('{');
          const lastBrace = rawText.lastIndexOf('}');
          if (firstBrace !== -1 && lastBrace !== -1) {
              const potentialJson = rawText.substring(firstBrace, lastBrace + 1);
              parsed = JSON.parse(potentialJson);
              cleanTextResponse = rawText.replace(potentialJson, "").trim();
          }
      }

      if (parsed) {
          extractedTransactions = parsed.extractedTransactions || [];
          extractedClients = parsed.extractedClients || [];
          updates = parsed.updates || [];
          deletions = parsed.deletions || [];
      }
  } catch (e) {
      console.warn("Erro ao parsear JSON da IA", e);
  }

  // Adiciona indicador de qual IA foi usada se for OpenAI (para transparência)
  if (providerUsed === 'OPENAI') {
      cleanTextResponse += "\n\n🤖 *Processado via OpenAI (Fallback)*";
  }

  return { textResponse: cleanTextResponse, extractedTransactions, extractedClients, updates, deletions };
};
