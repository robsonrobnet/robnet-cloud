
import React, { useState } from 'react';
import { ShieldCheck, Loader2, CreditCard, Building2, UserPlus, LogIn, FileText, Download, AlertTriangle, Settings, Database, X, Save, Phone, Fingerprint, Key, Check, Copy, Mail } from 'lucide-react';
import { supabase, formatSupabaseError, updateSupabaseConfig } from '../lib/supabase';
import { User, UserRole, UserPlan, Language } from '../types';
import { EmailService } from '../services/emailService';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
  t: any;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess, t }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({
    username: '', // Nome/Empresa
    password: '',
    email: '', // Novo campo
    whatsapp: '',
    document: '', // CPF ou CNPJ
    plan: 'FREE' as UserPlan,
    companyName: '',
    cnpj: ''
  });
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [emailStatus, setEmailStatus] = useState<'IDLE' | 'SENDING' | 'SENT' | 'ERROR'>('IDLE');

  // Success Modal State
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [generatedAccessKey, setGeneratedAccessKey] = useState('');

  // DB Config State
  const [showConfig, setShowConfig] = useState(false);
  const [dbSettings, setDbSettings] = useState({
    url: localStorage.getItem('finanai_db_url') || '',
    key: localStorage.getItem('finanai_db_key') || ''
  });

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    updateSupabaseConfig(dbSettings.url, dbSettings.key);
    setShowConfig(false);
    alert("Conexão atualizada com sucesso! Tente realizar o login novamente.");
  };

  const setupSQL = `-- FINANAI OS v5.3 - SOFT DELETE & SEGURANÇA
-- Execute este script no SQL Editor do Supabase para atualizar a estrutura.

-- 1. Habilitar Extensões
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Tabela: EMPRESAS (Tenant Principal)
CREATE TABLE IF NOT EXISTS public.companies (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  plan TEXT DEFAULT 'FREE' CHECK (plan IN ('FREE', 'START', 'PRO', 'ENTERPRISE')),
  cnpj TEXT,
  owner_id UUID,
  scheduled_deletion_date TIMESTAMPTZ, -- Nova Coluna para exclusão agendada
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- GARANTIA: Adiciona coluna de exclusão se não existir
ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS scheduled_deletion_date TIMESTAMPTZ;

-- 3. Tabela: USUÁRIOS
CREATE TABLE IF NOT EXISTS public.users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID REFERENCES public.companies(id) ON DELETE CASCADE, -- Se a empresa for excluída, usuários somem
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  email TEXT,
  whatsapp TEXT,
  document_number TEXT,
  access_key TEXT UNIQUE,
  role TEXT DEFAULT 'USER' CHECK (role IN ('USER', 'ADMIN', 'MANAGER')),
  language TEXT DEFAULT 'pt',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- GARANTIA: Adiciona colunas novas caso a tabela já exista
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS whatsapp TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS document_number TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS access_key TEXT UNIQUE;

-- 4. Tabela: CATEGORIAS
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID REFERENCES public.companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  color TEXT DEFAULT '#10b981',
  icon TEXT DEFAULT 'Tag',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Tabela: TRANSAÇÕES (Segurança de Dados Aprimorada)
CREATE TABLE IF NOT EXISTS public.transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  -- ON DELETE SET NULL: Se o usuário for excluído, a transação PERMANECE na empresa (Histórico seguro)
  user_id UUID REFERENCES public.users(id) ON DELETE SET NULL, 
  -- ON DELETE CASCADE: Se a empresa for excluída, os dados somem (Isolamento total)
  company_id UUID REFERENCES public.companies(id) ON DELETE CASCADE,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  category TEXT, 
  description TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  type TEXT CHECK (type IN ('INCOME', 'EXPENSE')),
  status TEXT DEFAULT 'PAID' CHECK (status IN ('PAID', 'PENDING', 'OVERDUE')),
  cost_type TEXT DEFAULT 'VARIABLE' CHECK (cost_type IN ('FIXED', 'VARIABLE')),
  scope TEXT DEFAULT 'BUSINESS' CHECK (scope IN ('PERSONAL', 'BUSINESS')),
  date DATE DEFAULT CURRENT_DATE,
  due_date DATE,
  is_recurring BOOLEAN DEFAULT FALSE,
  installment_current INTEGER, 
  installment_total INTEGER, 
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.companies ADD COLUMN IF NOT EXISTS owner_id UUID;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS category TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS is_recurring BOOLEAN DEFAULT FALSE;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS installment_current INTEGER;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS installment_total INTEGER;

-- 6. Tabela: CHAT (Histórico Pessoal)
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE, -- Chat é pessoal, apaga com usuário
  role TEXT CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  timestamp BIGINT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. PERMISSÕES DE ACESSO
ALTER TABLE public.companies DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages DISABLE ROW LEVEL SECURITY;

NOTIFY pgrst, 'reload schema';
`;

  const generateAccessKey = () => {
    // Gera uma chave estilo XXXX-XXXX-XXXX
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Sem O, 0, I, 1 para evitar confusão
    let key = '';
    for (let i = 0; i < 12; i++) {
        if (i > 0 && i % 4 === 0) key += '-';
        key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return key;
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setEmailStatus('IDLE');

    const cleanUsername = formData.username.trim();
    const cleanPassword = formData.password.trim();

    try {
      if (isRegistering) {
        // --- REGISTRO COM CHAVE DE ACESSO ---
        if (cleanUsername.length < 3) throw new Error("Nome deve ter pelo menos 3 caracteres.");
        if (cleanPassword.length < 4) throw new Error("Senha deve ter pelo menos 4 caracteres.");
        if (!formData.email || !formData.email.includes('@')) throw new Error("E-mail válido é obrigatório.");
        if (!formData.whatsapp) throw new Error("WhatsApp é obrigatório para recuperação.");
        if (!formData.document) throw new Error("CPF/CNPJ é obrigatório.");

        const accessKey = generateAccessKey();
        
        // Nome da empresa padrão se não for Pro/Enterprise
        const finalCompanyName = formData.companyName.trim() 
          ? formData.companyName 
          : `${cleanUsername} Corp`;

        // 1. Cria a Empresa (ISOLAMENTO: Cada registro cria uma empresa nova)
        const { data: compData, error: compError } = await supabase
          .from('companies')
          .insert([{ 
            name: finalCompanyName, 
            plan: formData.plan,
            cnpj: formData.cnpj || formData.document // Usa o documento como CNPJ se não informado outro
          }])
          .select()
          .single();
        
        if (compError) throw compError;

        // 2. Cria o Usuário com Dados Estendidos
        const { data: userData, error: userError } = await supabase
          .from('users')
          .insert([{
            company_id: compData.id,
            username: cleanUsername,
            password: cleanPassword,
            email: formData.email,
            whatsapp: formData.whatsapp,
            document_number: formData.document,
            access_key: accessKey,
            role: 'ADMIN',
            language: 'pt'
          }])
          .select()
          .single();

        if (userError) {
          await supabase.from('companies').delete().eq('id', compData.id); // Rollback
          throw userError;
        }

        // 3. Atualiza Owner da Empresa
        await supabase.from('companies').update({ owner_id: userData.id }).eq('id', compData.id);

        // 4. Categorias Padrão (Específicas para esta empresa)
        const defaultCats = [
          { company_id: compData.id, name: 'Vendas / Serviços', color: '#10b981', icon: 'Wallet' },
          { company_id: compData.id, name: 'Custos Operacionais', color: '#ef4444', icon: 'TrendingDown' },
          { company_id: compData.id, name: 'Pessoal & Salários', color: '#ec4899', icon: 'Users' },
          { company_id: compData.id, name: 'Impostos', color: '#f59e0b', icon: 'Landmark' },
          { company_id: compData.id, name: 'Marketing', color: '#8b5cf6', icon: 'Zap' }
        ];
        await supabase.from('categories').insert(defaultCats);

        // 5. ENVIO DE E-MAIL (Edge Function)
        setEmailStatus('SENDING');
        const emailResult = await EmailService.sendWelcomeEmail(
          formData.email, 
          cleanUsername, 
          accessKey, 
          formData.plan
        );
        
        if (emailResult.success) {
          setEmailStatus('SENT');
        } else {
          console.warn("Falha no envio de e-mail:", emailResult.error);
          setEmailStatus('ERROR');
        }

        // SUCESSO - Exibir Modal com a Chave
        setGeneratedAccessKey(accessKey);
        setShowSuccessModal(true);

      } else {
        // --- LOGIN PADRÃO ---
        // Tenta logar por Username ou Access Key
        const { data: userCandidates, error: searchError } = await supabase
          .from('users')
          .select('*, companies(*)')
          .or(`username.ilike.${cleanUsername},access_key.eq.${cleanUsername}`); // Permite logar com a chave no campo usuário

        if (searchError) {
           if (searchError.code === '42703') throw new Error("Erro de Schema. Rode o 'System Override' abaixo para atualizar o banco.");
           throw searchError;
        }

        const user = userCandidates?.find(u => u.password === cleanPassword);

        if (!user) {
           throw new Error('Credenciais inválidas. Verifique Usuário/Chave e Senha.');
        }

        const companyData = Array.isArray(user.companies) ? user.companies[0] : user.companies;
        
        // Verifica agendamento de exclusão
        if (companyData && companyData.scheduled_deletion_date) {
            const deletionDate = new Date(companyData.scheduled_deletion_date);
            const now = new Date();
            
            // Se já passou da data, bloqueia (ou a lógica de backend já deveria ter deletado)
            if (now > deletionDate) {
                throw new Error("Esta conta foi desativada e excluída permanentemente conforme solicitação.");
            }
            // Aviso de conta em processo de exclusão (mas ainda permite acesso até a data)
            alert(`ATENÇÃO: Esta conta está agendada para exclusão definitiva em ${deletionDate.toLocaleDateString()}. O acesso será revogado após esta data.`);
        }

        onLoginSuccess({
          id: user.id,
          company_id: user.company_id,
          username: user.username,
          email: user.email,
          role: user.role as UserRole,
          plan: (companyData?.plan || 'FREE') as UserPlan,
          language: (user.language as Language) || 'pt',
          createdAt: user.created_at,
          access_key: user.access_key
        });
      }
    } catch (err: any) { 
      console.error(err);
      setError(formatSupabaseError(err)); 
    } finally { 
      setIsLoading(false); 
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedAccessKey);
    alert("Chave copiada!");
  };

  const handleCloseSuccess = () => {
    setShowSuccessModal(false);
    setIsRegistering(false);
    setFormData({ ...formData, username: '', password: '', whatsapp: '', document: '', email: '' });
  };

  return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center p-6 relative overflow-hidden font-inter">
      <div className="absolute top-[-10%] left-[-5%] w-[60%] h-[60%] bg-indigo-500/10 rounded-full blur-[120px]"></div>
      
      {/* SUCCESS MODAL */}
      {showSuccessModal && (
         <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in">
             <div className="bg-slate-900 border border-emerald-500/30 p-8 rounded-[2rem] w-full max-w-md shadow-2xl relative text-center">
                 <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                     <Check size={40} className="text-emerald-500" />
                 </div>
                 <h2 className="text-2xl font-black text-white mb-2">Credencial Criada!</h2>
                 <p className="text-slate-400 text-sm mb-4">Sua conta foi ativada. Abaixo está sua Chave de Acesso Única.</p>
                 
                 {emailStatus === 'SENT' && (
                    <div className="mb-6 bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center justify-center gap-2">
                       <Mail size={14} /> E-mail de confirmação enviado!
                    </div>
                 )}
                 {emailStatus === 'ERROR' && (
                    <div className="mb-6 bg-rose-500/10 p-3 rounded-xl border border-rose-500/20 text-rose-400 text-xs font-bold flex items-center justify-center gap-2">
                       <AlertTriangle size={14} /> Falha ao enviar e-mail. Salve a chave agora!
                    </div>
                 )}
                 
                 <div className="bg-black/50 p-4 rounded-xl border border-slate-700 mb-6 relative group">
                     <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Sua Access Key</p>
                     <p className="text-xl font-mono font-black text-emerald-400 tracking-wider">{generatedAccessKey}</p>
                     <button onClick={copyToClipboard} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-500 hover:text-white transition-colors">
                         <Copy size={18} />
                     </button>
                 </div>

                 <div className="bg-indigo-500/10 p-4 rounded-xl border border-indigo-500/20 mb-6">
                     <p className="text-xs text-indigo-300">
                        🎁 <strong>Você ganhou 15 dias de teste grátis!</strong><br/>
                        Aproveite acesso total a todas as funcionalidades.
                     </p>
                 </div>

                 <button onClick={handleCloseSuccess} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-4 rounded-xl font-black uppercase tracking-widest text-xs transition-all">
                     Acessar Terminal Agora
                 </button>
             </div>
         </div>
      )}

      {/* Config Button */}
      <button 
        onClick={() => setShowConfig(true)}
        className="absolute top-6 right-6 z-20 text-slate-500 hover:text-indigo-500 transition-colors p-2 rounded-xl hover:bg-white/5"
      >
        <Settings size={24} />
      </button>

      {/* Config Modal */}
      {showConfig && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem] w-full max-w-md shadow-2xl relative">
              <button onClick={() => setShowConfig(false)} className="absolute top-4 right-4 text-slate-500 hover:text-white"><X size={20}/></button>
              <h3 className="text-lg font-black text-white mb-4">Configuração Database</h3>
              <form onSubmit={handleSaveConfig} className="space-y-4">
                 <input className="w-full bg-black/30 border border-slate-700 rounded-xl p-3 text-white text-xs outline-none" placeholder="URL" value={dbSettings.url} onChange={e => setDbSettings({...dbSettings, url: e.target.value})} />
                 <input type="password" className="w-full bg-black/30 border border-slate-700 rounded-xl p-3 text-white text-xs outline-none" placeholder="Key" value={dbSettings.key} onChange={e => setDbSettings({...dbSettings, key: e.target.value})} />
                 <button className="w-full bg-indigo-600 text-white py-3 rounded-xl font-black text-xs uppercase">Salvar</button>
              </form>
           </div>
        </div>
      )}

      <div className="w-full max-w-[480px] relative z-10">
        <div className="bg-slate-900/40 backdrop-blur-3xl border border-white/10 rounded-[3rem] p-8 md:p-12 shadow-2xl transition-all duration-500">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-indigo-600 rounded-[1.5rem] mx-auto flex items-center justify-center text-white shadow-2xl mb-4 border border-indigo-400/20">
              <Key size={32} />
            </div>
            <h1 className="text-2xl font-black text-white tracking-tighter uppercase">FinanAI <span className="text-indigo-500">Access V5.3</span></h1>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] mt-2">Secure Multi-Tenant System</p>
          </div>
          
          <form onSubmit={handleAuth} className="space-y-4">
            <div className="space-y-3">
              {/* Username / Name */}
              <div className="relative">
                  <UserPlus className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                  <input 
                    type="text" 
                    value={formData.username} 
                    onChange={e => setFormData({...formData, username: e.target.value})} 
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 text-white font-bold text-sm outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-600" 
                    placeholder={isRegistering ? "Nome Completo / Empresa" : "Usuário ou Access Key"} 
                    required 
                  />
              </div>

              {/* Password */}
              <div className="relative">
                  <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                  <input 
                    type="password" 
                    value={formData.password} 
                    onChange={e => setFormData({...formData, password: e.target.value})} 
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 text-white font-bold text-sm outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-600" 
                    placeholder="Senha de Acesso" 
                    required 
                  />
              </div>

              {/* Extra Fields for Registration */}
              {isRegistering && (
                <div className="space-y-3 animate-in slide-in-from-top-4 pt-2">
                  <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                      <input 
                        type="email" 
                        value={formData.email} 
                        onChange={e => setFormData({...formData, email: e.target.value})} 
                        className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 text-white font-bold text-xs outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-600" 
                        placeholder="E-mail Corporativo" 
                        required 
                      />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                      <div className="relative">
                          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                          <input 
                            type="text" 
                            value={formData.whatsapp} 
                            onChange={e => setFormData({...formData, whatsapp: e.target.value})} 
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 text-white font-bold text-xs outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-600" 
                            placeholder="WhatsApp/Tel" 
                            required 
                          />
                      </div>
                      <div className="relative">
                          <Fingerprint className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                          <input 
                            type="text" 
                            value={formData.document} 
                            onChange={e => setFormData({...formData, document: e.target.value})} 
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 text-white font-bold text-xs outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-600" 
                            placeholder="CPF ou CNPJ" 
                            required 
                          />
                      </div>
                  </div>

                  <div className="relative">
                    <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                    <select 
                      value={formData.plan} 
                      onChange={e => setFormData({...formData, plan: e.target.value as UserPlan})} 
                      className="w-full bg-slate-900/80 border border-white/10 rounded-2xl p-4 pl-12 text-white font-bold text-xs outline-none focus:border-indigo-500/50 transition-all appearance-none"
                    >
                      <option value="FREE">Plano BÁSICO (Gratuito)</option>
                      <option value="START">Plano INTERMEDIÁRIO (Start)</option>
                      <option value="PRO">Plano PROFISSIONAL (Pro)</option>
                      <option value="ENTERPRISE">Plano ENTERPRISE (Corp)</option>
                    </select>
                  </div>
                  
                  <p className="text-[10px] text-emerald-400 text-center font-bold">
                    ✨ 15 dias de teste grátis no plano selecionado (Enterprise Trial)
                  </p>
                </div>
              )}
            </div>

            {error && (
              <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 flex items-center gap-3">
                  <AlertTriangle className="text-rose-400 shrink-0" size={16} />
                  <p className="text-[11px] text-rose-200 font-bold">{error}</p>
              </div>
            )}
            
            <button type="submit" disabled={isLoading} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-[1.5rem] py-4 font-black uppercase tracking-widest transition-all shadow-xl disabled:opacity-50 flex items-center justify-center gap-2 mt-4">
              {isLoading ? <Loader2 className="animate-spin" size={20} /> : (
                isRegistering ? (emailStatus === 'SENDING' ? 'Enviando E-mail...' : 'Gerar Credencial') : 'Acessar Terminal'
              )}
            </button>
            
            <div className="flex flex-col gap-3 pt-4">
              <button 
                type="button" 
                onClick={() => { setIsRegistering(!isRegistering); setError(null); }} 
                className="w-full text-[10px] text-slate-400 font-bold uppercase tracking-widest hover:text-white transition-colors"
              >
                {isRegistering ? 'Já tenho uma chave' : 'Criar Nova Credencial'}
              </button>
              
              <button 
                type="button" 
                onClick={() => { 
                  const blob = new Blob([setupSQL], { type: 'text/plain' }); 
                  const url = URL.createObjectURL(blob); 
                  const a = document.createElement('a'); 
                  a.href = url; 
                  a.download = 'setup_finanai_v5_3.sql'; 
                  a.click(); 
                }} 
                className="w-full bg-slate-800/50 hover:bg-white/10 text-slate-500 hover:text-white p-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2"
              >
                <Download size={12} /> System Override: Baixar SQL v5.3 (Correção)
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
