
import React, { useState, useEffect } from 'react';
import { 
  FileText, Users, Briefcase, Settings, Plus, Save, Trash2, Edit, CheckCircle2, 
  AlertTriangle, Upload, Search, Building2, User, FileOutput, ShieldCheck, RefreshCw, Loader2, X,
  Printer, Download, Mail, Eye, FileCode, Share2, Ban, Wifi, WifiOff, Activity
} from 'lucide-react';
import { supabase, formatSupabaseError } from '../lib/supabase';
import { User as UserType, NfseClient, NfseService, NfseConfig, NfseRps } from '../types';

interface NfseManagerProps {
  currentUser: UserType;
}

// Extended type for joined data
interface ExtendedRps extends NfseRps {
    nfse_clients?: NfseClient;
    nfse_services?: NfseService;
}

const NfseManager: React.FC<NfseManagerProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'ISSUANCE' | 'CLIENTS' | 'SERVICES' | 'CONFIG'>('ISSUANCE');
  const [loading, setLoading] = useState(false);
  
  // Data States
  const [clients, setClients] = useState<NfseClient[]>([]);
  const [services, setServices] = useState<NfseService[]>([]);
  const [config, setConfig] = useState<NfseConfig | null>(null);
  const [history, setHistory] = useState<ExtendedRps[]>([]);

  // UI States
  const [showForm, setShowForm] = useState(false);
  const [selectedNote, setSelectedNote] = useState<ExtendedRps | null>(null); // For Visualization Modal
  const [sendingEmailId, setSendingEmailId] = useState<string | null>(null);
  const [webserviceStatus, setWebserviceStatus] = useState<'IDLE' | 'CHECKING' | 'ONLINE' | 'OFFLINE'>('IDLE');
  
  // Auxiliary States
  const [consultingCnpj, setConsultingCnpj] = useState(false);
  const [consultingIm, setConsultingIm] = useState(false);

  const [newClient, setNewClient] = useState<Partial<NfseClient>>({ doc_type: 'CNPJ', address_state: 'SP' });
  const [newService, setNewService] = useState<Partial<NfseService>>({ iss_retained: false });
  const [issueData, setIssueData] = useState({
    client_id: '',
    service_id: '',
    value: '',
    description_override: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [cl, sv, cf, hs] = await Promise.all([
        supabase.from('nfse_clients').select('*').eq('company_id', currentUser.company_id),
        supabase.from('nfse_services').select('*').eq('company_id', currentUser.company_id),
        supabase.from('nfse_config').select('*').eq('company_id', currentUser.company_id).single(),
        // Fetch full related data for invoice generation
        supabase.from('nfse_rpss')
            .select('*, nfse_clients(*), nfse_services(*)')
            .eq('company_id', currentUser.company_id)
            .order('created_at', { ascending: false })
      ]);

      if (cl.data) setClients(cl.data);
      if (sv.data) setServices(sv.data);
      if (cf.data) setConfig(cf.data);
      if (hs.data) setHistory(hs.data as ExtendedRps[]);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [currentUser.company_id]);

  // --- WEBSERVICE ACTIONS ---

  const handleTestWebservice = async () => {
      setWebserviceStatus('CHECKING');
      // Simulação de Handshake com a Prefeitura de SP (SOAP)
      setTimeout(() => {
          // 90% de chance de sucesso para simulação
          const success = Math.random() > 0.1;
          setWebserviceStatus(success ? 'ONLINE' : 'OFFLINE');
          if (!success) alert("Falha ao conectar com o WebService da Prefeitura (Timeout ou Certificado Inválido).");
      }, 2000);
  };

  // --- DATA ACTIONS ---

  const handleConsultCnpj = async () => {
    const cnpj = newClient.doc_number?.replace(/\D/g, '');
    if (!cnpj || cnpj.length !== 14) {
      alert("Por favor, digite um CNPJ válido (14 dígitos) para consultar.");
      return;
    }

    setConsultingCnpj(true);
    try {
      const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`);
      if (!response.ok) throw new Error("Erro ao consultar CNPJ.");
      
      const data = await response.json();
      if (data) {
          setNewClient(prev => ({
                  ...prev,
                  name: data.razao_social || data.nome_fantasia || prev.name,
                  email: data.email?.toLowerCase() || prev.email,
                  address_street: data.logradouro || prev.address_street,
                  address_number: data.numero || 'S/N',
                  address_complement: data.complemento || '',
                  address_neighborhood: data.bairro || prev.address_neighborhood,
                  address_zip: data.cep ? data.cep.replace(/\D/g, '') : prev.address_zip,
                  address_state: data.uf || prev.address_state,
                  address_city_name: data.municipio || prev.address_city_name,
                  address_city_code: data.codigo_municipio || prev.address_city_code
          }));
      }
    } catch (e: any) {
        alert("Consulta falhou: " + e.message);
    } finally {
        setConsultingCnpj(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload: any = {
        company_id: currentUser.company_id,
        im: config?.im,
        rps_series: config?.rps_series || '1',
        last_rps_number: config?.last_rps_number || 0,
        certificate_password: config?.certificate_password
      };
      if (config?.certificate_pfx_base64) payload.certificate_pfx_base64 = config.certificate_pfx_base64;

      const { error } = await supabase.from('nfse_config').upsert(payload, { onConflict: 'company_id' });
      if (error) throw error;
      alert("Configurações salvas com sucesso!");
      fetchData();
    } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleSaveClient = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = { ...newClient, company_id: currentUser.company_id };
      const { error } = await supabase.from('nfse_clients').upsert(payload);
      if (error) throw error;
      alert("Cliente salvo com sucesso.");
      setShowForm(false);
      setNewClient({ doc_type: 'CNPJ', address_state: 'SP' });
      fetchData();
    } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = { ...newService, company_id: currentUser.company_id };
      const { error } = await supabase.from('nfse_services').upsert(payload);
      if (error) throw error;
      alert("Serviço salvo com sucesso.");
      setShowForm(false);
      setNewService({ iss_retained: false });
      fetchData();
    } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleDelete = async (table: string, id: string) => {
    if(!confirm("Excluir registro permanentemente?")) return;
    try {
        const { error } = await supabase.from(table).delete().eq('id', id);
        if (error) throw error;
        if (table === 'nfse_clients') setClients(prev => prev.filter(i => i.id !== id));
        if (table === 'nfse_services') setServices(prev => prev.filter(i => i.id !== id));
        fetchData();
    } catch(e: any) { alert("Erro ao excluir: " + formatSupabaseError(e)); }
  };

  const handleCertUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64 = (reader.result as string).split(',')[1];
              setConfig(prev => ({
                  id: prev?.id || '',
                  company_id: currentUser.company_id,
                  im: prev?.im || '',
                  rps_series: prev?.rps_series || '1',
                  last_rps_number: prev?.last_rps_number || 0,
                  certificate_password: prev?.certificate_password,
                  certificate_pfx_base64: base64
              }));
          };
          reader.readAsDataURL(file);
      }
  };

  const handleIssueRPS = async () => {
      if (!config) {
          alert("Configure a Série e Numeração do RPS na aba Configurações antes de emitir.");
          setActiveTab('CONFIG');
          return;
      }
      const client = clients.find(c => c.id === issueData.client_id);
      const service = services.find(s => s.id === issueData.service_id);
      if (!client || !service || !issueData.value) {
          alert("Preencha todos os campos obrigatórios (Tomador, Serviço e Valor).");
          return;
      }

      setLoading(true);
      try {
          const val = parseFloat(issueData.value);
          const iss = val * (service.aliquot || 0);
          let totalLiquid = val;
          if (service.iss_retained) totalLiquid -= iss;
          
          const rpsNum = (config.last_rps_number || 0) + 1;
          const payload = {
              company_id: currentUser.company_id,
              client_id: client.id,
              service_id: service.id,
              rps_number: rpsNum,
              rps_series: config.rps_series || '1',
              service_amount: val,
              iss_amount: iss,
              total_amount: totalLiquid,
              status: 'NORMAL',
              issue_date: new Date().toISOString().split('T')[0],
              transmission_status: 'TRANSMITTING' // Simulando envio imediato
          };

          const { data: rpsData, error } = await supabase.from('nfse_rpss').insert([payload]).select().single();
          if (error) throw error;

          // Atualiza numeração
          await supabase.from('nfse_config').update({ last_rps_number: rpsNum }).eq('id', config.id);

          // Simula Delay de Processamento da Prefeitura
          setTimeout(async () => {
              // 1. Atualiza Status para AUTORIZADO
              await supabase.from('nfse_rpss').update({ 
                  transmission_status: 'AUTHORIZED',
                  nfe_number: 20240000 + rpsNum,
                  nfe_verification_code: Math.random().toString(36).substring(7).toUpperCase()
              }).eq('id', rpsData.id);

              // 2. Lança no Financeiro
              await supabase.from('transactions').insert([{
                  user_id: currentUser.id,
                  company_id: currentUser.company_id,
                  description: `NFS-e ${rpsNum} - ${client.name}`,
                  amount: totalLiquid,
                  type: 'INCOME',
                  status: 'PENDING',
                  category: 'Vendas / Serviços',
                  date: new Date().toISOString().split('T')[0],
                  scope: 'BUSINESS'
              }]);

              alert(`RPS Nº ${rpsNum} Transmitido e Autorizado com Sucesso!`);
              fetchData();
              setIssueData({ client_id: '', service_id: '', value: '', description_override: '' });
              setLoading(false);
          }, 3000); // 3 segundos de "processamento"

      } catch (e: any) { 
          alert(formatSupabaseError(e)); 
          setLoading(false);
      } 
  };

  const handleCancelNote = async (note: ExtendedRps) => {
      if (note.status === 'CANCELADO') return alert("Esta nota já está cancelada.");
      
      const reason = prompt("Motivo do cancelamento (Obrigatório para Prefeitura):");
      if (!reason) return;
      
      if (!confirm("Tem certeza? O cancelamento é irreversível.")) return;

      try {
          const { error } = await supabase.from('nfse_rpss')
              .update({ status: 'CANCELADO', transmission_status: 'REJECTED' })
              .eq('id', note.id);
              
          if (error) throw error;
          fetchData();
          alert(`NFS-e ${note.rps_number} cancelada com sucesso.`);
      } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  // --- XML & PRINT ---

  const generateXML = (note: ExtendedRps) => {
      return `<?xml version="1.0" encoding="UTF-8"?>
<PedidoEnvioLoteRPS xmlns="http://www.prefeitura.sp.gov.br/nfe">
  <Cabecalho Versao="1">
    <CPFCNPJRemetente>
      <CNPJ>${currentUser.username}</CNPJ>
    </CPFCNPJRemetente>
  </Cabecalho>
  <RPS>
    <InfRps Id="RPS${note.rps_number}">
      <IdentificacaoRps>
        <Numero>${note.rps_number}</Numero>
        <Serie>${note.rps_series}</Serie>
        <Tipo>1</Tipo>
      </IdentificacaoRps>
      <DataEmissao>${new Date(note.issue_date).toISOString()}</DataEmissao>
      <NaturezaOperacao>1</NaturezaOperacao>
      <OptanteSimplesNacional>1</OptanteSimplesNacional>
      <IncentivadorCultural>2</IncentivadorCultural>
      <Status>${note.status === 'CANCELADO' ? '2' : '1'}</Status>
      <Servico>
        <Valores>
          <ValorServicos>${note.service_amount.toFixed(2)}</ValorServicos>
          <ValorIss>${note.iss_amount.toFixed(2)}</ValorIss>
          <Aliquota>${(note.nfse_services?.aliquot || 0).toFixed(4)}</Aliquota>
        </Valores>
        <ItemListaServico>${note.nfse_services?.code}</ItemListaServico>
        <Discriminacao>${note.nfse_services?.description}</Discriminacao>
        <CodigoMunicipio>3550308</CodigoMunicipio>
      </Servico>
      <Prestador>
        <Cnpj>${currentUser.username}</Cnpj>
        <InscricaoMunicipal>${config?.im}</InscricaoMunicipal>
      </Prestador>
      <Tomador>
        <IdentificacaoTomador>
          <CpfCnpj>
            <Cnpj>${note.nfse_clients?.doc_number}</Cnpj>
          </CpfCnpj>
        </IdentificacaoTomador>
        <RazaoSocial>${note.nfse_clients?.name}</RazaoSocial>
        <Endereco>
          <Endereco>${note.nfse_clients?.address_street}</Endereco>
          <Numero>${note.nfse_clients?.address_number}</Numero>
          <Bairro>${note.nfse_clients?.address_neighborhood}</Bairro>
          <CodigoMunicipio>${note.nfse_clients?.address_city_code}</CodigoMunicipio>
          <Uf>${note.nfse_clients?.address_state}</Uf>
          <Cep>${note.nfse_clients?.address_zip}</Cep>
        </Endereco>
      </Tomador>
    </InfRps>
  </RPS>
</PedidoEnvioLoteRPS>`;
  };

  const handleDownloadXML = (note: ExtendedRps) => {
      const xml = generateXML(note);
      const blob = new Blob([xml], { type: 'text/xml' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `RPS_${note.rps_number}_${note.rps_series}.xml`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
  };

  const handlePrintNote = (note: ExtendedRps) => {
      const printWindow = window.open('', '_blank', 'width=800,height=900');
      if (!printWindow) return;

      const html = `
        <html>
        <head>
            <title>NFS-e - ${note.rps_number}</title>
            <style>
                body { font-family: 'Arial', sans-serif; padding: 40px; font-size: 12px; color: #333; }
                .header-img { width: 100%; text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
                .box { border: 1px solid #000; padding: 10px; margin-bottom: 5px; }
                .title { font-weight: bold; font-size: 14px; text-align: center; background: #eee; padding: 5px; margin: -10px -10px 10px -10px; border-bottom: 1px solid #000; }
                .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
                .label { font-weight: bold; margin-right: 5px; }
                .cancelado { color: red; font-size: 24px; font-weight: bold; text-align: center; border: 3px solid red; padding: 10px; margin-bottom: 20px; transform: rotate(-5deg); }
                .code { font-family: monospace; font-size: 14px; letter-spacing: 2px; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th, td { border: 1px solid #ccc; padding: 8px; text-align: right; }
                th { background: #f9f9f9; text-align: left; }
            </style>
        </head>
        <body>
            <div class="header-img">
                <h2>PREFEITURA DO MUNICÍPIO DE SÃO PAULO</h2>
                <h3>NOTA FISCAL DE SERVIÇOS ELETRÔNICA - NFS-e</h3>
            </div>

            ${note.status === 'CANCELADO' ? '<div class="cancelado">CANCELADA</div>' : ''}

            <div class="box">
                <div class="row">
                    <div><span class="label">Número da Nota:</span> <span class="code">${note.nfe_number || 'AGUARDANDO'}</span></div>
                    <div><span class="label">Data e Hora de Emissão:</span> ${new Date(note.issue_date).toLocaleString()}</div>
                    <div><span class="label">Código de Verificação:</span> <span class="code">${note.nfe_verification_code || '---'}</span></div>
                </div>
            </div>

            <div class="box">
                <div class="title">PRESTADOR DE SERVIÇOS</div>
                <div class="row"><span class="label">Razão Social:</span> <span>${currentUser.username}</span></div>
                <div class="row"><span class="label">CPF/CNPJ:</span> <span>${currentUser.username} (Simulado)</span></div>
                <div class="row"><span class="label">Inscrição Municipal:</span> <span>${config?.im || '-'}</span></div>
                <div class="row"><span class="label">Município:</span> <span>São Paulo - SP</span></div>
            </div>

            <div class="box">
                <div class="title">TOMADOR DE SERVIÇOS</div>
                <div class="row"><span class="label">Razão Social:</span> <span>${note.nfse_clients?.name}</span></div>
                <div class="row"><span class="label">CPF/CNPJ:</span> <span>${note.nfse_clients?.doc_number}</span></div>
                <div class="row"><span class="label">Endereço:</span> <span>${note.nfse_clients?.address_street}, ${note.nfse_clients?.address_number}</span></div>
                <div class="row"><span class="label">Município:</span> <span>${note.nfse_clients?.address_city_name || ''} - ${note.nfse_clients?.address_state}</span></div>
            </div>

            <div class="box" style="min-height: 100px;">
                <div class="title">DISCRIMINAÇÃO DOS SERVIÇOS</div>
                <p>${note.nfse_services?.description}</p>
            </div>

            <div class="box">
                <div class="title">VALORES E IMPOSTOS</div>
                <table>
                    <tr><th>Valor Total do Serviço</th><td>R$ ${note.service_amount.toFixed(2)}</td></tr>
                    <tr><th>Deduções</th><td>R$ 0,00</td></tr>
                    <tr><th>Base de Cálculo</th><td>R$ ${note.service_amount.toFixed(2)}</td></tr>
                    <tr><th>Alíquota ISS</th><td>${((note.nfse_services?.aliquot || 0) * 100).toFixed(2)}%</td></tr>
                    <tr><th>Valor ISS</th><td>R$ ${note.iss_amount.toFixed(2)}</td></tr>
                    <tr><th>Outras Retenções</th><td>R$ 0,00</td></tr>
                    <tr style="font-size: 16px; font-weight: bold;"><th>VALOR LÍQUIDO</th><td>R$ ${note.total_amount.toFixed(2)}</td></tr>
                </table>
            </div>
            
            <div style="text-align: center; margin-top: 20px; font-size: 10px; color: #666;">
                Este documento é uma representação gráfica da NFS-e. A validade pode ser verificada no site da prefeitura.
            </div>
            <script>window.print();</script>
        </body>
        </html>
      `;
      printWindow.document.write(html);
      printWindow.document.close();
  };

  const handleSendEmail = async (note: ExtendedRps) => {
      const email = note.nfse_clients?.email;
      if (!email) return alert("Cliente não possui e-mail cadastrado.");
      if (!confirm(`Enviar nota para ${email}?`)) return;

      setSendingEmailId(note.id);
      setTimeout(() => {
          setSendingEmailId(null);
          alert(`E-mail com a Nota Fiscal enviado com sucesso para ${email}!`);
      }, 2000);
  };

  // Standard input class
  const inputClass = "w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs font-bold text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500/20";
  const highlightInputClass = "w-full bg-slate-800 text-white border border-slate-700 rounded-xl p-3 text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500/50 placeholder:text-slate-400";

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20 relative">
        {/* VISUALIZATION MODAL */}
        {selectedNote && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in">
                <div className="bg-white dark:bg-slate-900 rounded-[2rem] w-full max-w-3xl shadow-2xl relative animate-in zoom-in-95 border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh]">
                    <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                        <div>
                            <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2"><FileText className="text-indigo-500"/> Nota Fiscal Paulistana</h3>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
                                {selectedNote.nfe_number ? `NFS-e Nº ${selectedNote.nfe_number}` : `RPS Nº ${selectedNote.rps_number} (Em Processamento)`}
                            </p>
                        </div>
                        <button onClick={() => setSelectedNote(null)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"><X size={20} className="text-slate-400"/></button>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                        {/* MOCK RECEIPT LAYOUT */}
                        <div className="border border-slate-200 dark:border-slate-700 rounded-xl p-6 bg-slate-50 dark:bg-slate-950/50 relative overflow-hidden">
                            {selectedNote.status === 'CANCELADO' && (
                                <div className="absolute top-10 right-[-50px] rotate-45 bg-rose-500 text-white px-10 py-1 text-xs font-black uppercase shadow-lg z-10">CANCELADA</div>
                            )}
                            <div className="grid grid-cols-2 gap-8 mb-8 border-b border-dashed border-slate-300 dark:border-slate-700 pb-6">
                                <div>
                                    <p className="text-[10px] font-black uppercase text-slate-400 mb-1">Prestador de Serviços</p>
                                    <p className="font-bold text-slate-800 dark:text-white text-sm">{currentUser.username}</p>
                                    <p className="text-xs text-slate-500">Inscrição Municipal: {config?.im || 'Não informada'}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-[10px] font-black uppercase text-slate-400 mb-1">Tomador de Serviços</p>
                                    <p className="font-bold text-slate-800 dark:text-white text-sm">{selectedNote.nfse_clients?.name}</p>
                                    <p className="text-xs text-slate-500">{selectedNote.nfse_clients?.doc_number}</p>
                                    <p className="text-xs text-slate-500">{selectedNote.nfse_clients?.address_city_name} - {selectedNote.nfse_clients?.address_state}</p>
                                </div>
                            </div>

                            <div className="mb-8">
                                <p className="text-[10px] font-black uppercase text-slate-400 mb-2">Discriminação dos Serviços</p>
                                <p className="text-sm text-slate-700 dark:text-slate-300 font-medium leading-relaxed">{selectedNote.nfse_services?.description}</p>
                                <p className="text-xs text-slate-500 mt-1">Cód. Serviço (LC 116): {selectedNote.nfse_services?.code}</p>
                            </div>

                            <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
                                <div className="flex justify-between mb-2">
                                    <span className="text-xs text-slate-500">Valor Serviço</span>
                                    <span className="text-xs font-bold">R$ {selectedNote.service_amount.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between mb-2">
                                    <span className="text-xs text-slate-500">ISS ({( (selectedNote.nfse_services?.aliquot || 0)*100 ).toFixed(2)}%)</span>
                                    <span className="text-xs font-bold text-rose-500">- R$ {selectedNote.iss_amount.toFixed(2)}</span>
                                </div>
                                <div className="border-t border-slate-100 dark:border-slate-700 my-2 pt-2 flex justify-between">
                                    <span className="text-sm font-black uppercase text-slate-800 dark:text-white">Valor Líquido</span>
                                    <span className="text-sm font-black text-emerald-600">R$ {selectedNote.total_amount.toFixed(2)}</span>
                                </div>
                            </div>
                            
                            {selectedNote.nfe_verification_code && (
                                <div className="mt-4 text-center">
                                    <p className="text-[10px] text-slate-400 uppercase tracking-widest">Código de Verificação</p>
                                    <p className="text-lg font-mono font-bold text-slate-600 dark:text-slate-400 tracking-widest">{selectedNote.nfe_verification_code}</p>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="p-6 border-t border-slate-100 dark:border-slate-800 flex gap-3 bg-white dark:bg-slate-900 rounded-b-[2rem]">
                        <button onClick={() => handlePrintNote(selectedNote)} className="flex-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 py-3 rounded-xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 transition-all">
                            <Printer size={16} /> Imprimir DANFE
                        </button>
                        <button onClick={() => handleDownloadXML(selectedNote)} className="flex-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-indigo-600 dark:text-indigo-400 py-3 rounded-xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 transition-all">
                            <FileCode size={16} /> Download XML
                        </button>
                        <button onClick={() => handleSendEmail(selectedNote)} disabled={!!sendingEmailId} className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 transition-all shadow-lg">
                            {sendingEmailId === selectedNote.id ? <Loader2 size={16} className="animate-spin" /> : <Mail size={16} />} 
                            Enviar por E-mail
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* Header */}
        <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]"></div>
            <div className="relative z-10 flex items-center justify-between">
                <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-emerald-600/20 text-emerald-400 rounded-2xl flex items-center justify-center border border-emerald-500/20">
                        <FileText size={28} />
                    </div>
                    <div>
                        <h2 className="text-xl font-black tracking-tight">NFS-e Paulistana</h2>
                        <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Gestão Inteligente de Documentos Fiscais</p>
                    </div>
                </div>
                <div className="hidden md:flex flex-col items-end">
                    <span className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Ambiente</span>
                    <span className="text-sm font-black text-emerald-400 flex items-center gap-2"><Wifi size={14} /> Produção (Simulado)</span>
                </div>
            </div>
        </div>

        {/* Tabs */}
        <div className="flex p-1.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-lg overflow-x-auto">
            {[
                { id: 'ISSUANCE', label: 'Emissão / Histórico', icon: FileOutput },
                { id: 'CLIENTS', label: 'Tomadores', icon: Users },
                { id: 'SERVICES', label: 'Serviços', icon: Briefcase },
                { id: 'CONFIG', label: 'Configurações', icon: Settings }
            ].map(tab => (
                <button
                    key={tab.id}
                    onClick={() => { setActiveTab(tab.id as any); setShowForm(false); }}
                    className={`flex-1 min-w-[120px] flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                        activeTab === tab.id ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-lg' : 'text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                >
                    <tab.icon size={14} /> {tab.label}
                </button>
            ))}
        </div>

        {/* Content Area */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 p-8 shadow-xl min-h-[400px]">
            
            {/* 1. ISSUANCE & HISTORY */}
            {activeTab === 'ISSUANCE' && (
                <div className="space-y-8 animate-in fade-in">
                    <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none"><FileText size={100} /></div>
                        <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest mb-4 flex items-center gap-2 relative z-10">
                            <Plus size={16} className="text-emerald-500" /> Nova Emissão de RPS (Recibo Provisório)
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end relative z-10">
                            <div className="lg:col-span-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Tomador de Serviço</label>
                                <select className={inputClass} value={issueData.client_id} onChange={e => setIssueData({...issueData, client_id: e.target.value})}>
                                    <option value="">Selecione o Cliente...</option>
                                    {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Serviço Prestado</label>
                                <select className={inputClass} value={issueData.service_id} onChange={e => setIssueData({...issueData, service_id: e.target.value})}>
                                    <option value="">Selecione...</option>
                                    {services.map(s => <option key={s.id} value={s.id}>{s.description} ({s.code})</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Valor Total (R$)</label>
                                <input type="number" className={inputClass} placeholder="0.00" value={issueData.value} onChange={e => setIssueData({...issueData, value: e.target.value})} />
                            </div>
                        </div>
                        <button onClick={handleIssueRPS} disabled={loading} className="mt-4 w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-3 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-emerald-600 transition-all shadow-lg flex items-center justify-center gap-2 relative z-10">
                            {loading ? <Loader2 className="animate-spin" size={16} /> : <Share2 size={16} />} 
                            Gerar Lote RPS e Transmitir
                        </button>
                    </div>

                    <div>
                        <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest mb-4">Histórico de Notas Emitidas</h3>
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead className="bg-slate-50 dark:bg-slate-800 text-[9px] font-black uppercase text-slate-400">
                                    <tr>
                                        <th className="px-4 py-3 text-left">Número / Série</th>
                                        <th className="px-4 py-3 text-left">Tomador</th>
                                        <th className="px-4 py-3 text-left">Emissão</th>
                                        <th className="px-4 py-3 text-right">Valor Líquido</th>
                                        <th className="px-4 py-3 text-center">Status Sefaz</th>
                                        <th className="px-4 py-3 text-center">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs font-bold">
                                    {history.map(h => (
                                        <tr key={h.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                                            <td className="px-4 py-3">
                                                {h.nfe_number ? (
                                                    <span className="text-indigo-600 dark:text-indigo-400">NFS-e {h.nfe_number}</span>
                                                ) : (
                                                    <span className="text-slate-500">RPS {h.rps_number}</span>
                                                )}
                                                <span className="text-slate-400 text-[10px] block">Série {h.rps_series}</span>
                                            </td>
                                            <td className="px-4 py-3 truncate max-w-[150px]">{h.nfse_clients?.name || 'Cliente Removido'}</td>
                                            <td className="px-4 py-3">{new Date(h.issue_date).toLocaleDateString()}</td>
                                            <td className="px-4 py-3 text-right font-black">R$ {h.total_amount.toFixed(2)}</td>
                                            <td className="px-4 py-3 text-center">
                                                <span className={`px-2 py-1 rounded-full text-[9px] uppercase flex items-center justify-center gap-1 w-fit mx-auto ${
                                                    h.status === 'CANCELADO' ? 'bg-rose-100 text-rose-600' : 
                                                    h.transmission_status === 'AUTHORIZED' ? 'bg-emerald-100 text-emerald-600' : 
                                                    h.transmission_status === 'TRANSMITTING' ? 'bg-indigo-100 text-indigo-600 animate-pulse' :
                                                    'bg-amber-100 text-amber-600'
                                                }`}>
                                                    {h.status === 'CANCELADO' ? <X size={10}/> : 
                                                     h.transmission_status === 'AUTHORIZED' ? <CheckCircle2 size={10}/> : 
                                                     h.transmission_status === 'TRANSMITTING' ? <RefreshCw size={10} className="animate-spin"/> :
                                                     <FileText size={10}/>}
                                                    {h.status === 'CANCELADO' ? 'Cancelada' : h.transmission_status === 'DRAFT' ? 'Rascunho' : h.transmission_status === 'TRANSMITTING' ? 'Processando' : 'Autorizada'}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3">
                                                <div className="flex items-center justify-center gap-1">
                                                    <button onClick={() => setSelectedNote(h)} className="p-1.5 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors" title="Visualizar Nota"><Eye size={16}/></button>
                                                    <button onClick={() => handleDownloadXML(h)} className="p-1.5 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors" title="Baixar XML"><FileCode size={16}/></button>
                                                    <button onClick={() => handleSendEmail(h)} disabled={!!sendingEmailId} className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors" title="Enviar por E-mail"><Mail size={16}/></button>
                                                    {h.status !== 'CANCELADO' && (
                                                        <button 
                                                            onClick={() => handleCancelNote(h)} 
                                                            className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors"
                                                            title="Cancelar Nota"
                                                        >
                                                            <Ban size={16}/>
                                                        </button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {history.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400 text-xs uppercase font-bold">Nenhuma nota emitida.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {/* 2. CONFIGURATION */}
            {activeTab === 'CONFIG' && (
                <div className="max-w-xl mx-auto space-y-6 animate-in fade-in">
                    {/* Status do WebService */}
                    <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-700">
                        <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Conectividade</h3>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${webserviceStatus === 'ONLINE' ? 'bg-emerald-100 text-emerald-600' : webserviceStatus === 'OFFLINE' ? 'bg-rose-100 text-rose-600' : 'bg-slate-200 text-slate-500'}`}>
                                    {webserviceStatus === 'ONLINE' ? <Wifi size={20}/> : webserviceStatus === 'OFFLINE' ? <WifiOff size={20}/> : <Activity size={20}/>}
                                </div>
                                <div>
                                    <p className="text-sm font-black text-slate-800 dark:text-white">WebService Prefeitura SP</p>
                                    <p className="text-[10px] font-bold text-slate-400 uppercase">
                                        Status: {webserviceStatus === 'IDLE' ? 'Aguardando Teste' : webserviceStatus === 'CHECKING' ? 'Verificando...' : webserviceStatus}
                                    </p>
                                </div>
                            </div>
                            <button onClick={handleTestWebservice} disabled={webserviceStatus === 'CHECKING'} className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg text-[10px] font-black uppercase tracking-wide hover:opacity-90 transition-opacity">
                                {webserviceStatus === 'CHECKING' ? 'Testando...' : 'Testar Conexão'}
                            </button>
                        </div>
                    </div>

                    <div className="flex items-center justify-between bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800 p-4 rounded-2xl">
                        <div className="flex gap-3">
                            <AlertTriangle className="text-amber-500 shrink-0" />
                            <p className="text-xs text-amber-700 dark:text-amber-400 font-bold">
                                Certificado Digital A1 é obrigatório para emissão real.
                            </p>
                        </div>
                        <div className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase flex items-center gap-1 ${config?.certificate_pfx_base64 ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-500'}`}>
                            {config?.certificate_pfx_base64 ? <><CheckCircle2 size={12} /> Carregado</> : 'Pendente'}
                        </div>
                    </div>
                    
                    <form onSubmit={handleSaveConfig} className="space-y-4">
                        <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Inscrição Municipal (Prestador)</label>
                            <input className={inputClass} value={config?.im || ''} onChange={e => setConfig(prev => prev ? ({...prev, im: e.target.value}) : { id: '', company_id: currentUser.company_id, im: e.target.value, rps_series: '1', last_rps_number: 0 } as any)} placeholder="Ex: 12345678" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Série RPS</label>
                                <input className={inputClass} value={config?.rps_series || '1'} onChange={e => setConfig(prev => prev ? ({...prev, rps_series: e.target.value}) : null)} />
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Último RPS Emitido</label>
                                <input type="number" className={inputClass} value={config?.last_rps_number || 0} onChange={e => setConfig(prev => prev ? ({...prev, last_rps_number: parseInt(e.target.value)}) : null)} />
                            </div>
                        </div>
                        
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 mb-2 block">Upload Certificado A1 (.pfx)</label>
                            <input type="file" accept=".pfx" onChange={handleCertUpload} className="block w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-black file:uppercase file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                        </div>

                        <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Senha do Certificado</label>
                            <input type="password" className={inputClass} value={config?.certificate_password || ''} onChange={e => setConfig(prev => prev ? ({...prev, certificate_password: e.target.value}) : null)} placeholder="******" />
                        </div>

                        <button type="submit" className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-4 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg flex items-center justify-center gap-2 mt-4 hover:bg-emerald-600 transition-all">
                            <Save size={16} /> Salvar Configurações
                        </button>
                    </form>
                </div>
            )}

            {/* 3. CLIENTS (Tomadores) */}
            {activeTab === 'CLIENTS' && (
                <div className="animate-in fade-in">
                    <div className="flex justify-between mb-4">
                        <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Tomadores Cadastrados</h3>
                        <button onClick={() => { setNewClient({ doc_type: 'CNPJ', address_state: 'SP' }); setShowForm(!showForm); }} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"><Plus size={14}/> Novo</button>
                    </div>

                    {showForm && (
                        <form onSubmit={handleSaveClient} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-3xl mb-6 border border-slate-200 dark:border-slate-700 grid grid-cols-1 md:grid-cols-2 gap-4 relative animate-in slide-in-from-top-2">
                            <button type="button" onClick={() => setShowForm(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"><X size={18}/></button>
                            <div className="md:col-span-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Razão Social / Nome</label>
                                <input className={inputClass} placeholder="Preenchimento automático após consulta" value={newClient.name || ''} onChange={e => setNewClient({...newClient, name: e.target.value})} required />
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Tipo de Documento</label>
                                <select className={highlightInputClass} value={newClient.doc_type} onChange={e => setNewClient({...newClient, doc_type: e.target.value as any})}>
                                    <option value="CNPJ">CNPJ</option><option value="CPF">CPF</option>
                                </select>
                            </div>
                            <div className="flex flex-col">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Número Documento</label>
                                <div className="flex gap-2">
                                    <input className={highlightInputClass} placeholder="Digite apenas números" value={newClient.doc_number || ''} onChange={e => setNewClient({...newClient, doc_number: e.target.value})} required />
                                    {newClient.doc_type === 'CNPJ' && (
                                        <button type="button" onClick={handleConsultCnpj} disabled={consultingCnpj} className="bg-blue-600 text-white px-4 rounded-xl font-bold text-xs uppercase hover:bg-blue-500 transition-colors flex items-center gap-2 shrink-0 h-full shadow-lg">
                                            {consultingCnpj ? <Loader2 size={16} className="animate-spin"/> : <Search size={16} />}
                                        </button>
                                    )}
                                </div>
                            </div>
                            <div className="flex flex-col">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Inscrição Municipal</label>
                                <div className="flex gap-2">
                                    <input className={inputClass} placeholder="Se houver" value={newClient.im || ''} onChange={e => setNewClient({...newClient, im: e.target.value})} />
                                </div>
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email</label>
                                <input className={inputClass} placeholder="contato@..." value={newClient.email || ''} onChange={e => setNewClient({...newClient, email: e.target.value})} />
                            </div>
                            <div className="md:col-span-2"><p className="text-[10px] font-black uppercase text-slate-400 mb-1 mt-2">Endereço</p></div>
                            <div className="md:col-span-2">
                                <input className={inputClass} placeholder="Logradouro (Rua, Av...)" value={newClient.address_street || ''} onChange={e => setNewClient({...newClient, address_street: e.target.value})} required />
                            </div>
                            <div>
                                <input className={inputClass} placeholder="Número" value={newClient.address_number || ''} onChange={e => setNewClient({...newClient, address_number: e.target.value})} required />
                            </div>
                            <div>
                                <input className={inputClass} placeholder="Bairro" value={newClient.address_neighborhood || ''} onChange={e => setNewClient({...newClient, address_neighborhood: e.target.value})} required />
                            </div>
                            <div>
                                <input className={inputClass} placeholder="CEP" value={newClient.address_zip || ''} onChange={e => setNewClient({...newClient, address_zip: e.target.value})} required />
                            </div>
                            <div>
                                <input className={inputClass} placeholder="Cód. Cidade (IBGE 7 dígitos)" value={newClient.address_city_code || ''} onChange={e => setNewClient({...newClient, address_city_code: e.target.value})} required />
                            </div>
                            <div className="md:col-span-2 flex gap-2 pt-2">
                                <button type="button" onClick={() => setShowForm(false)} className="flex-1 bg-slate-200 text-slate-500 py-3 rounded-xl font-black text-xs uppercase hover:bg-slate-300 transition-colors">Cancelar</button>
                                <button type="submit" className="flex-[3] bg-emerald-600 text-white py-3 rounded-xl font-black text-xs uppercase shadow-lg hover:bg-emerald-500 transition-colors">{newClient.id ? 'Salvar Alterações' : 'Salvar Cliente'}</button>
                            </div>
                        </form>
                    )}

                    <div className="space-y-2">
                        {clients.map(c => (
                            <div key={c.id} className="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                                <div><p className="font-bold text-sm text-slate-800 dark:text-white">{c.name}</p><p className="text-xs text-slate-400">{c.doc_type}: {c.doc_number}</p></div>
                                <div className="flex gap-2">
                                    <button onClick={() => { setNewClient(c); setShowForm(true); }} className="text-indigo-400 hover:text-indigo-600 p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg transition-colors"><Edit size={16}/></button>
                                    <button onClick={() => handleDelete('nfse_clients', c.id)} className="text-rose-400 hover:text-rose-600 p-2 bg-rose-50 dark:bg-rose-900/20 rounded-lg transition-colors"><Trash2 size={16}/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* 4. SERVICES */}
            {activeTab === 'SERVICES' && (
                <div className="animate-in fade-in">
                    <div className="flex justify-between mb-4">
                        <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Catálogo de Serviços</h3>
                        <button onClick={() => { setNewService({ iss_retained: false }); setShowForm(!showForm); }} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"><Plus size={14}/> Novo</button>
                    </div>

                    {showForm && (
                        <form onSubmit={handleSaveService} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-3xl mb-6 border border-slate-200 dark:border-slate-700 grid grid-cols-1 md:grid-cols-2 gap-4 relative animate-in slide-in-from-top-2">
                            <button type="button" onClick={() => setShowForm(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"><X size={18}/></button>
                            <div><input className={inputClass} placeholder="Código do Serviço (ex: 02800)" value={newService.code || ''} onChange={e => setNewService({...newService, code: e.target.value})} required /></div>
                            <div>
                                <input 
                                    type="number" 
                                    step="0.01" 
                                    className={inputClass} 
                                    placeholder="Alíquota % (ex: 2.9)" 
                                    value={newService.aliquot ? (newService.aliquot * 100) : ''} 
                                    onChange={e => setNewService({...newService, aliquot: parseFloat(e.target.value) / 100})} 
                                    required 
                                />
                            </div>
                            <div className="md:col-span-2"><input className={inputClass} placeholder="Descrição Padrão do Serviço" value={newService.description || ''} onChange={e => setNewService({...newService, description: e.target.value})} required /></div>
                            <div className="flex items-center gap-2"><input type="checkbox" checked={newService.iss_retained} onChange={e => setNewService({...newService, iss_retained: e.target.checked})} /><label className="text-xs font-bold text-slate-600 dark:text-slate-300">ISS Retido pelo Tomador?</label></div>
                            <div className="md:col-span-2 flex gap-2 pt-2">
                                <button type="button" onClick={() => setShowForm(false)} className="flex-1 bg-slate-200 text-slate-500 py-3 rounded-xl font-black text-xs uppercase hover:bg-slate-300 transition-colors">Cancelar</button>
                                <button type="submit" className="flex-[3] bg-emerald-600 text-white py-3 rounded-xl font-black text-xs uppercase shadow-lg hover:bg-emerald-500 transition-colors">{newService.id ? 'Salvar Alterações' : 'Salvar Serviço'}</button>
                            </div>
                        </form>
                    )}

                    <div className="space-y-2">
                        {services.map(s => (
                            <div key={s.id} className="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                                <div><p className="font-bold text-sm text-slate-800 dark:text-white">{s.description}</p><p className="text-xs text-slate-400">Cód: {s.code} • Alíquota: {(s.aliquot * 100).toFixed(2)}%</p></div>
                                <div className="flex gap-2">
                                    <button onClick={() => { setNewService(s); setShowForm(true); }} className="text-indigo-400 hover:text-indigo-600 p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg transition-colors"><Edit size={16}/></button>
                                    <button onClick={() => handleDelete('nfse_services', s.id)} className="text-rose-400 hover:text-rose-600 p-2 bg-rose-50 dark:bg-rose-900/20 rounded-lg transition-colors"><Trash2 size={16}/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

        </div>
    </div>
  );
};

export default NfseManager;
