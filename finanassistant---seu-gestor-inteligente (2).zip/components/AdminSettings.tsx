
import React, { useState, useEffect } from 'react';
import { 
  Shield, Users, Building2, Tags, Settings, Plus, Edit, Trash2, 
  Save, X, CheckCircle2, AlertTriangle, Database, Activity, Brain, Key, Server, Lock, FileText, Loader2, RefreshCw, Skull, Eraser
} from 'lucide-react';
import { supabase, formatSupabaseError, updateSupabaseConfig } from '../lib/supabase';
import { User, Company, Category, UserRole, UserPlan, Language } from '../types';
import { testGeminiConnection, testOpenAIConnection } from '../services/geminiService';
import { EmailService } from '../services/emailService';

interface AdminSettingsProps {
  currentUser: User;
  t: any;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  fetchData: () => void;
}

const AdminSettings: React.FC<AdminSettingsProps> = ({ 
  currentUser, t, language, onLanguageChange, fetchData 
}) => {
  const [activeTab, setActiveTab] = useState<'USERS' | 'COMPANIES' | 'CATEGORIES' | 'SYSTEM'>('USERS');
  const [isLoading, setIsLoading] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  
  // Data
  const [users, setUsers] = useState<User[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  // System Configuration State
  const [sysConfig, setSysConfig] = useState({
    dbUrl: localStorage.getItem('finanai_db_url') || '',
    dbKey: localStorage.getItem('finanai_db_key') || '',
    geminiKey: localStorage.getItem('finanai_gemini_key') || '',
    openaiKey: localStorage.getItem('finanai_openai_key') || ''
  });
  const [dbStatus, setDbStatus] = useState<'ONLINE' | 'OFFLINE' | 'CHECKING'>('CHECKING');
  const [geminiStatus, setGeminiStatus] = useState<'ONLINE' | 'OFFLINE' | 'CHECKING' | 'IDLE'>('IDLE');
  const [openaiStatus, setOpenaiStatus] = useState<'ONLINE' | 'OFFLINE' | 'CHECKING' | 'IDLE'>('IDLE');

  // Modals & Editing State
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<User> | null>(null);
  const [editPassword, setEditPassword] = useState('');

  const [showEditCompanyModal, setShowEditCompanyModal] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Partial<Company> | null>(null);

  const [showEditCategoryModal, setShowEditCategoryModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);

  // Initial Data Load
  useEffect(() => {
    fetchAdminData();
    checkDbConnection();
  }, [currentUser]);

  const checkDbConnection = async () => {
      setDbStatus('CHECKING');
      try {
          const { error } = await supabase.from('users').select('id').limit(1);
          if (!error) setDbStatus('ONLINE');
          else setDbStatus('OFFLINE');
      } catch {
          setDbStatus('OFFLINE');
      }
  };

  const handleTestGemini = async () => {
      if (!sysConfig.geminiKey) return;
      setGeminiStatus('CHECKING');
      const result = await testGeminiConnection(sysConfig.geminiKey);
      if (result.success) {
          setGeminiStatus('ONLINE');
          alert("Conexão com Gemini Bem-sucedida! IA Operacional.");
      } else {
          setGeminiStatus('OFFLINE');
          alert(`Falha na conexão Gemini: ${result.message}`);
      }
  };

  const handleTestOpenAI = async () => {
      if (!sysConfig.openaiKey) return;
      setOpenaiStatus('CHECKING');
      const result = await testOpenAIConnection(sysConfig.openaiKey);
      if (result.success) {
          setOpenaiStatus('ONLINE');
          alert("Conexão com OpenAI (GPT-4) Bem-sucedida!");
      } else {
          setOpenaiStatus('OFFLINE');
          alert(`Falha na conexão OpenAI: ${result.message}`);
      }
  };

  const fetchAdminData = async () => {
    setIsLoading(true);
    try {
      if (currentUser.role === 'MANAGER') {
          const { data: u } = await supabase.from('users').select('*');
          const { data: c } = await supabase.from('companies').select('*');
          const { data: cat } = await supabase.from('categories').select('*');
          setUsers(u || []);
          setCompanies(c || []);
          setCategories(cat || []);
      } else {
          // ADMIN view:
          // 1. Users associated with their primary company
          const { data: u } = await supabase.from('users').select('*').eq('company_id', currentUser.company_id);
          
          // 2. Companies: Their primary company OR companies they own
          const { data: c } = await supabase.from('companies').select('*').or(`id.eq.${currentUser.company_id},owner_id.eq.${currentUser.id}`);
          
          // 3. Categories: Associated with their primary company
          const { data: cat } = await supabase.from('categories').select('*').eq('company_id', currentUser.company_id);
          
          setUsers(u || []);
          setCompanies(c || []);
          setCategories(cat || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  // --- HANDLERS ---

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser || !editingUser.id) return;
    try {
        const payload: any = { 
            username: editingUser.username,
            role: editingUser.role
        };
        if (editPassword) payload.password = editPassword;

        const { error } = await supabase.from('users').update(payload).eq('id', editingUser.id);
        if (error) throw error;

        setShowEditUserModal(false);
        setEditingUser(null);
        setEditPassword('');
        fetchAdminData();
        alert("Usuário atualizado!");
    } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleDeleteUser = async (id: string) => {
      // Improved Warning Message
      if(!confirm("⚠️ AVISO DE EXCLUSÃO\n\nAo excluir este usuário:\n1. O acesso dele será revogado imediatamente.\n2. O histórico financeiro que ele lançou na empresa NÃO SERÁ APAGADO (Segurança de Dados).\n\nDeseja confirmar a remoção?")) return;
      try {
          const { error } = await supabase.from('users').delete().eq('id', id);
          if (error) throw error;
          fetchAdminData();
      } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleSaveCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCompany) return;
    
    try {
        if (editingCompany.id) {
            // Update
            const { error } = await supabase.from('companies').update({
                name: editingCompany.name,
                plan: editingCompany.plan,
                cnpj: editingCompany.cnpj
            }).eq('id', editingCompany.id);
            if (error) throw error;
            alert("Empresa atualizada!");
        } else {
            // Create New
            const { error } = await supabase.from('companies').insert([{
                name: editingCompany.name,
                plan: editingCompany.plan || 'FREE',
                cnpj: editingCompany.cnpj,
                owner_id: currentUser.id // Link to current user as owner
            }]);
            if (error) throw error;
            alert("Empresa cadastrada com sucesso!");
        }

        setShowEditCompanyModal(false);
        setEditingCompany(null);
        fetchAdminData();
        fetchData(); // Global update
    } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleDeleteCompany = async (id: string) => {
      // Bloqueia a exclusão da empresa ativa para evitar estado inconsistente
      if (id === currentUser.company_id) {
          alert("Não é possível excluir a empresa que está ATIVA no seu painel.\n\nPara excluir, alterne para outra empresa primeiro (se houver) ou contate o suporte.");
          return;
      }

      if (!confirm("⚠️ PERIGO: EXCLUSÃO DE EMPRESA\n\nEsta ação é IRREVERSÍVEL e apagará:\n- Todas as Transações Financeiras\n- Categorias Personalizadas\n- Usuários vinculados a esta empresa\n- Dados de NFS-e\n\nDeseja realmente continuar?")) return;
      
      setIsLoading(true);
      try {
          // 1. Limpeza Manual de Dependências (Garante exclusão mesmo sem CASCADE no banco)
          
          // Transações
          await supabase.from('transactions').delete().eq('company_id', id);
          
          // Categorias
          await supabase.from('categories').delete().eq('company_id', id);
          
          // Dados NFSe
          await supabase.from('nfse_rpss').delete().eq('company_id', id);
          await supabase.from('nfse_clients').delete().eq('company_id', id);
          await supabase.from('nfse_services').delete().eq('company_id', id);
          await supabase.from('nfse_config').delete().eq('company_id', id);

          // Usuários vinculados à empresa (Cuidado: remove acesso de quem for dessa empresa)
          await supabase.from('users').delete().eq('company_id', id);

          // 2. Exclui a Empresa
          const { error } = await supabase.from('companies').delete().eq('id', id);
          
          if (error) throw error;
          
          alert("Empresa e todos os dados associados foram removidos com sucesso.");
          await fetchAdminData();
          fetchData(); // Atualiza contexto global
      } catch (e: any) { 
          console.error("Erro exclusão:", e);
          alert("Erro ao excluir empresa: " + formatSupabaseError(e)); 
      } finally {
          setIsLoading(false);
      }
  };

  const handleUpdateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory || !editingCategory.id) return;
    try {
        const { error } = await supabase.from('categories').update({
            name: editingCategory.name,
            color: editingCategory.color,
            icon: editingCategory.icon
        }).eq('id', editingCategory.id);
        if (error) throw error;

        setShowEditCategoryModal(false);
        setEditingCategory(null);
        fetchAdminData();
        fetchData(); // Update global app state
        alert("Categoria atualizada!");
    } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleDeleteCategory = async (id: string) => {
      if(!confirm("Excluir categoria?")) return;
      try {
          const { error } = await supabase.from('categories').delete().eq('id', id);
          if (error) throw error;
          fetchAdminData();
          fetchData();
      } catch (e: any) { alert(formatSupabaseError(e)); }
  };

  const handleSaveDbConfig = () => {
      updateSupabaseConfig(sysConfig.dbUrl, sysConfig.dbKey);
      checkDbConnection();
      alert("Configuração de banco de dados atualizada!");
  };

  const handleSaveLLMConfig = () => {
      localStorage.setItem('finanai_gemini_key', sysConfig.geminiKey);
      localStorage.setItem('finanai_openai_key', sysConfig.openaiKey);
      alert("Chaves de API salvas localmente!");
  };

  const handleClearTransactions = async () => {
      const confirmText = "LIMPAR";
      const userInput = prompt(`⚠️ ATENÇÃO: LIMPEZA DE LANÇAMENTOS\n\nVocê está prestes a apagar TODO o histórico financeiro (Receitas e Despesas) da empresa ativa.\n\nCategorias, Usuários e Configurações SERÃO MANTIDOS.\n\nEsta ação é irreversível.\nDigite "${confirmText}" para confirmar:`);
      
      if (userInput !== confirmText) return;

      setIsLoading(true);
      try {
          // Exclui apenas as transações da empresa atual
          const { error } = await supabase
              .from('transactions')
              .delete()
              .eq('company_id', currentUser.company_id);

          if (error) throw error;

          alert("Base de lançamentos limpa com sucesso!");
          fetchData(); // Atualiza contexto global
          fetchAdminData(); // Atualiza estatísticas locais
      } catch (e: any) {
          alert("Erro ao limpar dados: " + formatSupabaseError(e));
      } finally {
          setIsLoading(false);
      }
  };

  const handleRequestAccountDeletion = async () => {
      const confirmText = "EXCLUIR";
      const userInput = prompt(`⚠️ ATENÇÃO: ENCERRAR CONTA\n\nVocê está prestes a agendar a exclusão da sua conta e de todos os dados da empresa.\n\nOs dados serão mantidos por 30 DIAS antes da remoção permanente, permitindo recuperação caso se arrependa.\n\nDigite "${confirmText}" para confirmar:`);
      
      if (userInput !== confirmText) return;

      setIsDeletingAccount(true);
      try {
          // 1. Calculate Deletion Date (30 days from now)
          const deletionDate = new Date();
          deletionDate.setDate(deletionDate.getDate() + 30);
          const dateStr = deletionDate.toISOString();

          // 2. Update Company with scheduled deletion
          const { error } = await supabase.from('companies')
              .update({ scheduled_deletion_date: dateStr })
              .eq('id', currentUser.company_id);

          if (error) throw error;

          // 3. Send Email Notification via Edge Function
          if (currentUser.email) {
              await EmailService.sendDeletionNotice(
                  currentUser.email,
                  currentUser.username,
                  deletionDate.toLocaleDateString()
              );
          }

          alert("Solicitação de encerramento processada.\n\nSua conta foi agendada para exclusão em 30 dias. Um e-mail de confirmação foi enviado.\n\nVocê será desconectado agora.");
          
          // 4. Logout (Force refresh/reload to clear state)
          localStorage.removeItem('finanai_session_v3');
          window.location.reload();

      } catch (e: any) {
          alert("Erro ao processar solicitação: " + formatSupabaseError(e));
          setIsDeletingAccount(false);
      }
  };

  // --- RENDER ---

  // Check if current user is the owner of the current company
  const isOwner = companies.find(c => c.id === currentUser.company_id)?.owner_id === currentUser.id;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      
      {/* HEADER */}
      <div className="bg-indigo-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
         <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-[80px]"></div>
         <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-5">
               <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center border border-white/20">
                  <Shield size={28} />
               </div>
               <div>
                  <h2 className="text-xl font-black tracking-tight">{currentUser.role === 'MANAGER' ? t.master_panel : t.admin_panel}</h2>
                  <p className="text-indigo-200 text-[10px] font-bold uppercase tracking-widest mt-1">Configurações do Sistema</p>
               </div>
            </div>
         </div>
      </div>

      {/* TABS */}
      <div className="flex p-1.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-lg overflow-x-auto">
         {[
            { id: 'USERS', label: 'Usuários', icon: Users },
            { id: 'COMPANIES', label: 'Empresas', icon: Building2 },
            { id: 'CATEGORIES', label: 'Categorias', icon: Tags },
            { id: 'SYSTEM', label: 'Sistema & APIs', icon: Server }
         ].map(tab => (
            <button
               key={tab.id}
               onClick={() => setActiveTab(tab.id as any)}
               className={`flex-1 min-w-[100px] flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  activeTab === tab.id ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-lg' : 'text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
               }`}
            >
               <tab.icon size={14} /> {tab.label}
            </button>
         ))}
      </div>

      {/* CONTENT AREA */}
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 p-8 shadow-xl min-h-[400px]">
         
         {/* USERS TAB */}
         {activeTab === 'USERS' && (
            <div className="space-y-4">
               <div className="flex justify-between items-center mb-4">
                  <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Usuários Registrados</h3>
                  <span className="text-xs font-bold text-slate-400">{users.length} usuários</span>
               </div>
               <div className="space-y-2">
                  {users.map(u => (
                     <div key={u.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                        <div className="flex items-center gap-3">
                           <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center font-bold text-xs uppercase">{u.username.substring(0,2)}</div>
                           <div>
                              <p className="text-sm font-bold text-slate-800 dark:text-white">{u.username}</p>
                              <p className="text-[10px] text-slate-400 font-bold uppercase">{u.role} • {new Date(u.createdAt).toLocaleDateString()}</p>
                           </div>
                        </div>
                        <div className="flex gap-2">
                           <button onClick={() => { setEditingUser(u); setShowEditUserModal(true); }} className="p-2 text-slate-400 hover:text-indigo-500 bg-white dark:bg-slate-900 rounded-lg shadow-sm"><Edit size={14}/></button>
                           {/* Permite que MANAGER ou ADMIN (se não for ele mesmo) excluam usuários */}
                           {(currentUser.role === 'MANAGER' || (currentUser.role === 'ADMIN' && u.id !== currentUser.id)) && (
                               <button onClick={() => handleDeleteUser(u.id)} className="p-2 text-slate-400 hover:text-rose-500 bg-white dark:bg-slate-900 rounded-lg shadow-sm" title="Excluir Usuário"><Trash2 size={14}/></button>
                           )}
                        </div>
                     </div>
                  ))}
               </div>
            </div>
         )}

         {/* COMPANIES TAB */}
         {activeTab === 'COMPANIES' && (
            <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                      <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Minhas Empresas</h3>
                      <p className="text-xs text-slate-400 mt-1">Gerencie os CNPJs do seu portfólio.</p>
                  </div>
                  <button onClick={() => { setEditingCompany({}); setShowEditCompanyModal(true); }} className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg transition-all">
                      <Plus size={14} /> Nova Empresa
                  </button>
               </div>
               
               <div className="grid grid-cols-1 gap-4">
                   {companies.map(c => {
                       const isMaster = c.id === currentUser.company_id;
                       return (
                          <div key={c.id} className={`flex items-center justify-between p-5 rounded-2xl border transition-all ${isMaster ? 'bg-indigo-50 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-900/30' : 'bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700'}`}>
                             <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isMaster ? 'bg-indigo-100 text-indigo-600' : 'bg-white dark:bg-slate-700 text-slate-400'}`}>
                                    <Building2 size={20} />
                                </div>
                                <div>
                                   <div className="flex items-center gap-2">
                                       <p className="text-sm font-bold text-slate-800 dark:text-white">{c.name}</p>
                                       {isMaster && <span className="bg-indigo-600 text-white px-2 py-0.5 rounded text-[9px] font-black uppercase">Ativa</span>}
                                   </div>
                                   <div className="flex items-center gap-3 mt-1">
                                       <p className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1"><FileText size={10} /> {c.cnpj || 'Sem CNPJ'}</p>
                                       <p className="text-[10px] text-slate-400 font-bold uppercase">• Plano: {c.plan}</p>
                                   </div>
                                </div>
                             </div>
                             <div className="flex gap-2">
                                <button onClick={() => { setEditingCompany(c); setShowEditCompanyModal(true); }} className="p-2 text-slate-400 hover:text-indigo-500 bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700"><Edit size={16}/></button>
                                {!isMaster && (
                                    <button onClick={() => handleDeleteCompany(c.id)} className="p-2 text-slate-400 hover:text-rose-500 bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700"><Trash2 size={16}/></button>
                                )}
                             </div>
                          </div>
                       );
                   })}
               </div>
            </div>
         )}

         {/* CATEGORIES TAB */}
         {activeTab === 'CATEGORIES' && (
            <div className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Categorias Financeiras</h3>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {categories.map(c => (
                     <div key={c.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                        <div className="flex items-center gap-3">
                           <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: c.color + '20', color: c.color }}>
                              <Tags size={16} />
                           </div>
                           <p className="text-xs font-bold text-slate-700 dark:text-slate-300">{c.name}</p>
                        </div>
                        <div className="flex gap-1">
                           <button onClick={() => { setEditingCategory(c); setShowEditCategoryModal(true); }} className="p-1.5 text-slate-400 hover:text-indigo-500"><Edit size={14}/></button>
                           <button onClick={() => handleDeleteCategory(c.id)} className="p-1.5 text-slate-400 hover:text-rose-500"><Trash2 size={14}/></button>
                        </div>
                     </div>
                  ))}
               </div>
            </div>
         )}

         {/* SYSTEM TAB */}
         {activeTab === 'SYSTEM' && (
             <div className="space-y-8 animate-in fade-in">
                 
                 {/* IDIOMA */}
                 <div>
                     <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest mb-4">Preferências Regionais</h3>
                     <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700">
                         <div className="flex gap-2">
                             {(['pt', 'en', 'es'] as const).map(lang => (
                                 <button 
                                    key={lang}
                                    onClick={() => onLanguageChange(lang)}
                                    className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase transition-all ${language === lang ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-900 text-slate-500'}`}
                                 >
                                    {lang === 'pt' ? 'Português' : lang === 'en' ? 'English' : 'Español'}
                                 </button>
                             ))}
                         </div>
                     </div>
                 </div>

                 {/* DATABASE CONFIG */}
                 <div>
                     <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest flex items-center gap-2"><Database size={16} /> Banco de Dados</h3>
                        <div className={`flex items-center gap-2 text-[10px] font-black uppercase px-3 py-1 rounded-full ${dbStatus === 'ONLINE' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                            {dbStatus === 'CHECKING' ? <Activity size={12} className="animate-spin" /> : dbStatus === 'ONLINE' ? <CheckCircle2 size={12} /> : <AlertTriangle size={12} />}
                            {dbStatus}
                        </div>
                     </div>
                     <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 space-y-4">
                         <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Project URL</label>
                            <input className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs font-bold text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500/20" value={sysConfig.dbUrl} onChange={e => setSysConfig({...sysConfig, dbUrl: e.target.value})} placeholder="https://..." />
                         </div>
                         <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Anon Public Key</label>
                            <div className="relative">
                                <Key className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                <input type="password" className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 pl-9 text-xs font-bold text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500/20" value={sysConfig.dbKey} onChange={e => setSysConfig({...sysConfig, dbKey: e.target.value})} placeholder="eyJ..." />
                            </div>
                         </div>
                         <button onClick={handleSaveDbConfig} className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-3 rounded-xl font-black uppercase tracking-widest text-xs shadow-md">Salvar & Testar Conexão</button>
                     </div>
                 </div>

                 {/* DATA MAINTENANCE (NEW SECTION) */}
                 {isOwner && (
                     <div className="border-t border-slate-200 dark:border-slate-700 pt-8">
                         <div className="bg-amber-50 dark:bg-amber-900/10 p-6 rounded-3xl border border-amber-200 dark:border-amber-900/30">
                             <h3 className="text-sm font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest flex items-center gap-2 mb-4">
                                <Eraser size={18} /> Manutenção de Dados
                             </h3>
                             <p className="text-xs text-amber-800 dark:text-amber-300 font-medium mb-6 leading-relaxed">
                                Precisa recomeçar os lançamentos? Esta opção limpa todas as transações financeiras (receitas e despesas) da empresa ativa, mas <strong>mantém categorias, usuários e configurações intactos</strong>.
                             </p>
                             <button 
                                onClick={handleClearTransactions} 
                                disabled={isLoading}
                                className="w-full bg-amber-600 hover:bg-amber-700 text-white py-4 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                             >
                                {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Eraser size={16} />}
                                Limpar Lançamentos Financeiros
                             </button>
                         </div>
                     </div>
                 )}

                 {/* LLM CONFIG */}
                 <div>
                     <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest flex items-center gap-2"><Brain size={16} /> Inteligência Artificial (LLM)</h3>
                     </div>
                     
                     <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 space-y-4">
                         
                         {/* GEMINI */}
                         <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                             <div className="flex justify-between items-center mb-2">
                                 <span className="text-xs font-black text-slate-700 dark:text-white flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-blue-500"></div> Google Gemini (Padrão)</span>
                                 <div className="flex gap-2">
                                     <button onClick={handleTestGemini} className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg text-[9px] font-black uppercase flex items-center gap-1 transition-all">
                                         <RefreshCw size={10} /> Testar
                                     </button>
                                     <span className={`text-[9px] font-bold uppercase flex items-center gap-1 ${sysConfig.geminiKey ? 'text-emerald-500' : 'text-slate-400'}`}>
                                         {geminiStatus !== 'IDLE' && (geminiStatus === 'ONLINE' ? <CheckCircle2 size={10}/> : <AlertTriangle size={10}/>)}
                                         {sysConfig.geminiKey ? 'Ativo' : 'N/A'}
                                     </span>
                                 </div>
                             </div>
                             <div className="relative">
                                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                <input type="password" className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 pl-9 text-xs font-bold text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-blue-500/20" value={sysConfig.geminiKey} onChange={e => setSysConfig({...sysConfig, geminiKey: e.target.value})} placeholder="AIza..." />
                             </div>
                         </div>

                         {/* CHAT GPT */}
                         <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                             <div className="flex justify-between items-center mb-2">
                                 <span className="text-xs font-black text-slate-700 dark:text-white flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> OpenAI (Fallback)</span>
                                 <div className="flex gap-2">
                                     <button onClick={handleTestOpenAI} className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg text-[9px] font-black uppercase flex items-center gap-1 transition-all">
                                         <RefreshCw size={10} /> Testar
                                     </button>
                                     <span className={`text-[9px] font-bold uppercase flex items-center gap-1 ${sysConfig.openaiKey ? 'text-emerald-500' : 'text-slate-400'}`}>
                                         {openaiStatus !== 'IDLE' && (openaiStatus === 'ONLINE' ? <CheckCircle2 size={10}/> : <AlertTriangle size={10}/>)}
                                         {sysConfig.openaiKey ? 'Ativo' : 'N/A'}
                                     </span>
                                 </div>
                             </div>
                             <div className="relative">
                                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                <input type="password" className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 pl-9 text-xs font-bold text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500/20" value={sysConfig.openaiKey} onChange={e => setSysConfig({...sysConfig, openaiKey: e.target.value})} placeholder="sk-..." />
                             </div>
                         </div>

                         <button onClick={handleSaveLLMConfig} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl font-black uppercase tracking-widest text-xs shadow-md transition-all">Salvar Chaves de API</button>
                     </div>
                 </div>

                 {/* ACCOUNT DELETION ZONE (OWNER ONLY) */}
                 {isOwner && (
                     <div className="border-t border-slate-200 dark:border-slate-700 pt-8">
                         <div className="bg-rose-50 dark:bg-rose-900/10 p-6 rounded-3xl border border-rose-200 dark:border-rose-900/30">
                             <h3 className="text-sm font-black text-rose-600 dark:text-rose-400 uppercase tracking-widest flex items-center gap-2 mb-4">
                                <Skull size={18} /> Zona de Perigo (Encerramento)
                             </h3>
                             <p className="text-xs text-rose-800 dark:text-rose-300 font-medium mb-6 leading-relaxed">
                                Deseja encerrar definitivamente sua assinatura? <br/>
                                Seus dados serão mantidos por <strong className="underline">30 dias</strong> para recuperação e então apagados permanentemente.
                                Um e-mail de confirmação será enviado.
                             </p>
                             <button 
                                onClick={handleRequestAccountDeletion} 
                                disabled={isDeletingAccount}
                                className="w-full bg-rose-600 hover:bg-rose-700 text-white py-4 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                             >
                                {isDeletingAccount ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                                Encerrar Conta & Apagar Dados
                             </button>
                         </div>
                     </div>
                 )}
                 
             </div>
         )}
      </div>

      {/* MODALS REUSED FROM PREVIOUS COMPONENT */}
      {showEditUserModal && editingUser && (<div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in"><div className="bg-white dark:bg-slate-900 rounded-[2rem] p-8 w-full max-w-md shadow-2xl relative animate-in zoom-in-95 border border-slate-100 dark:border-slate-700"><button onClick={() => { setShowEditUserModal(false); setEditingUser(null); }} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"><X size={20} /></button><div className="mb-6 flex items-center gap-4"><div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center"><Edit size={24} /></div><div><h3 className="text-xl font-black text-slate-800 dark:text-white">Editar Usuário</h3></div></div><form onSubmit={handleUpdateUser} className="space-y-4"><input className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" value={editingUser.username} onChange={e => setEditingUser({...editingUser, username: e.target.value})} required /><select className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" value={editingUser.role} onChange={e => setEditingUser({...editingUser, role: e.target.value as any})} disabled={currentUser.role !== 'MANAGER'}><option value="USER">Free / Usuário Padrão</option><option value="ADMIN">Admin</option>{currentUser.role === 'MANAGER' && <option value="MANAGER">Manager</option>}</select><input type="password" className="w-full bg-emerald-50/50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" placeholder="Redefinir Senha (Opcional)" value={editPassword} onChange={e => setEditPassword(e.target.value)} minLength={4} /><button className="w-full bg-slate-900 dark:bg-slate-800 text-white py-3.5 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg mt-2 hover:bg-slate-800">Salvar Alterações</button></form></div></div>)}
      {showEditCompanyModal && editingCompany && (<div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in"><div className="bg-white dark:bg-slate-900 rounded-[2rem] p-8 w-full max-w-md shadow-2xl relative animate-in zoom-in-95 border border-slate-100 dark:border-slate-700"><button onClick={() => { setShowEditCompanyModal(false); setEditingCompany(null); }} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"><X size={20} /></button><div className="mb-6 flex items-center gap-4"><div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center"><Building2 size={24} /></div><div><h3 className="text-xl font-black text-slate-800 dark:text-white">{editingCompany.id ? 'Editar Empresa' : 'Nova Empresa'}</h3></div></div><form onSubmit={handleSaveCompany} className="space-y-4"><div><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome</label><input className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" value={editingCompany.name || ''} onChange={e => setEditingCompany({...editingCompany, name: e.target.value})} required /></div><div><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">CNPJ</label><input className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" placeholder="00.000.000/0000-00" value={editingCompany.cnpj || ''} onChange={e => setEditingCompany({...editingCompany, cnpj: e.target.value})} /></div><div><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Plano</label><select className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" value={editingCompany.plan || 'FREE'} onChange={e => setEditingCompany({...editingCompany, plan: e.target.value as any})}><option value="FREE">Free</option><option value="START">Start</option><option value="PRO">Pro</option><option value="ENTERPRISE">Enterprise</option></select></div><button className="w-full bg-slate-900 dark:bg-slate-800 text-white py-3.5 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg mt-2 hover:bg-emerald-600 transition-all">Salvar</button></form></div></div>)}
      {showEditCategoryModal && editingCategory && (<div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in"><div className="bg-white dark:bg-slate-900 rounded-[2rem] p-8 w-full max-w-md shadow-2xl relative animate-in zoom-in-95 border border-slate-100 dark:border-slate-700"><button onClick={() => { setShowEditCategoryModal(false); setEditingCategory(null); }} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"><X size={20} /></button><div className="mb-6 flex items-center gap-4"><div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center"><Tags size={24} /></div><div><h3 className="text-xl font-black text-slate-800 dark:text-white">Editar Categoria</h3></div></div><form onSubmit={handleUpdateCategory} className="space-y-4"><div><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome</label><input className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" value={editingCategory.name} onChange={e => setEditingCategory({...editingCategory, name: e.target.value})} required /></div><div className="flex gap-2"><div className="flex-none"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Cor</label><input type="color" className="h-[46px] w-full rounded-xl border-0 bg-transparent cursor-pointer" value={editingCategory.color} onChange={e => setEditingCategory({...editingCategory, color: e.target.value})} /></div><div className="flex-1"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Ícone</label><input className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-800 dark:text-white outline-none" value={editingCategory.icon} onChange={e => setEditingCategory({...editingCategory, icon: e.target.value})} /></div></div><button className="w-full bg-slate-900 dark:bg-slate-800 text-white py-3.5 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg mt-2 hover:bg-slate-800">Salvar</button></form></div></div>)}

    </div>
  );
};

export default AdminSettings;
